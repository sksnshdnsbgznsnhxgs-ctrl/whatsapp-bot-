let handler = async (m, { conn, text, usedPrefix, command }) => {
  // ⬇️ لو كتب الوقت بس - تشغيل التايمر
  if (text && !isNaN(text)) {
    let minutes = parseInt(text)
    if (minutes < 1) minutes = 1
    
    // ⬇️ رسالة تأكيد
    await m.reply(`╭━❪ 𖤐 𝑷𝑹𝑶𝑻𝑶𝑻𝒀𝑷𝑬 𝑽2 𖤐 ❫━╮
│
│ ⏰⃝🩸 *تـم تـفـعـيـل الـريـسـتـارت*
│
│ 🔄⃝🜲 *الـمـدة:* ${minutes} دقـيـقـة
│ ⏳⃝🜲 *سـيـتـم إعـادة الـتـشـغـيـل تـلـقـائـيـاً*
│
╰━❪ 𖤐 𝑷𝑹𝑶𝑻𝑶𝑻𝒀𝑷𝑬 𝑽2 𖤐 ❫━╯`)
    
    // ⬇️ ضبط التايمر
    setTimeout(() => {
      console.log('🔄 إعادة تشغيل تلقائية...')
      process.exit(1) // يقفل البوت - المنصة هتشغله تاني
    }, minutes * 60 * 1000) // تحويل الدقائق لملي ثانية
    
  } else {
    // ⬇️ لو كتب الأمر بس - عرض المساعدة
    return m.reply(`╭━❪ 𖤐 𝑷𝑹𝑶𝑻𝑶𝑻𝒀𝑷𝑬 𝑽2 𖤐 ❫━╮
│
│ 🜲⃝☠️ *إعـادة تـشـغـيـل تـلـقـائـي*
│
│ ⚡⃝🜲 *الاستخدام:*
│ ${usedPrefix + command} ⧼الوقت بالدقائق⧽
│
│ 📌⃝🩸 *مثال:*
│ ${usedPrefix + command} 30
│ ${usedPrefix + command} 60
│ ${usedPrefix + command} 120
│
│ ⚠️⃝🩸 *لإلغاء التايمر:*
│ ${usedPrefix + command} 0
│
╰━❪ 𖤐 𝑷𝑹𝑶𝑻𝑶𝑻𝒀𝑷𝑬 𝑽2 𖤐 ❫━╯`)
  }
}

handler.command = ['ريستارت', 'restart', 'اعاده']
handler.help = ['ريستارت']
handler.tags = ['owner']
handler.owner = +855 31 218 0919

export default handler