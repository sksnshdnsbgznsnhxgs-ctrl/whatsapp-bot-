// plugins/banchat.js
// ⧼ 𝑷𝑹𝑶𝑻𝑶𝑻𝒀𝑷𝑬 ⧽v2 - حظر البوت في الجروب 🚫

import { theme } from '../core/theme.js';

// لتخزين آخر مرة تم إرسال رسالة الحظر لكل جروب
const lastBanMessageSent = {};

let handler = async (m, { conn, text, usedPrefix, command, isOwner }) => {
    
    // التحقق من صلاحيات المطور
    if (!isOwner) {
        return conn.reply(m.chat, theme.build([
            { type: 'title', text: 'خـطـأ' },
            { type: 'subtitle', text: 'هذا الأمر مخصص للمطور فقط' }
        ]), m);
    }

    // عرض حالة الجروب الحالية
    if (!text) {
        const isBanned = global.db.data.chats[m.chat]?.isBanned || false;
        const status = isBanned ? '🟢 محظور' : '🔴 غير محظور';
        
        return conn.reply(m.chat, theme.build([
            { type: 'title', text: '🚫 حـظـر الـبـوت' },
            { type: 'divider' },
            { type: 'info', label: 'الـجـروب', value: m.chat.split('@')[0] },
            { type: 'info', label: 'الـحـالـة', value: status },
            { type: 'divider' },
            { type: 'line', text: `${usedPrefix}${command} تفعيل - لحظر البوت في هذا الجروب` },
            { type: 'line', text: `${usedPrefix}${command} تعطيل - لإلغاء حظر البوت` }
        ]), m);
    }

    // تفعيل الحظر
    if (text === 'تفعيل') {
        if (!global.db.data.chats[m.chat]) {
            global.db.data.chats[m.chat] = {};
        }
        global.db.data.chats[m.chat].isBanned = true;
        
        return conn.reply(m.chat, theme.build([
            { type: 'title', text: '✅ تـم الـتـفـعـيـل' },
            { type: 'subtitle', text: 'تم حظر البوت في هذا الجروب' },
            { type: 'divider' },
            { type: 'line', text: '⚠️ لن يستجيب البوت لأي أمر هنا' }
        ]), m);
    }
    
    // تعطيل الحظر
    if (text === 'تعطيل') {
        if (!global.db.data.chats[m.chat]) {
            global.db.data.chats[m.chat] = {};
        }
        global.db.data.chats[m.chat].isBanned = false;
        
        return conn.reply(m.chat, theme.build([
            { type: 'title', text: '✅ تـم الـتـعـطـيـل' },
            { type: 'subtitle', text: 'تم إلغاء حظر البوت في هذا الجروب' },
            { type: 'divider' },
            { type: 'line', text: '✅ البوت يعمل بشكل طبيعي الآن' }
        ]), m);
    }

    return conn.reply(m.chat, theme.build([
        { type: 'title', text: 'خـطـأ' },
        { type: 'subtitle', text: 'استخدم: تفعيل أو تعطيل' }
    ]), m);
};

// 🔥 معالج منع الأوامر في الجروب المحظور
handler.before = async (m, { conn, isOwner }) => {
    
    // إذا كان الجروب محظور
    if (global.db.data.chats[m.chat]?.isBanned === true) {
        
        // السماح للمطور باستخدام الأوامر حتى لو الجروب محظور
        if (isOwner) return false;
        
        // التحقق إذا كان الأمر من الأوامر (مش رسالة عادية)
        const isCommand = m.text && (m.text.startsWith('.') || m.text.startsWith('/') || m.text.startsWith('#') || m.text.startsWith('!'));
        
        if (isCommand) {
            const now = Date.now();
            const lastSent = lastBanMessageSent[m.chat] || 0;
            
            // إرسال رسالة مرة كل 30 دقيقة (نصف ساعة)
            if (now - lastSent > 30 * 60 * 1000) {
                lastBanMessageSent[m.chat] = now;
                
                await conn.reply(m.chat, theme.build([
                    { type: 'title', text: '🚫 جـروب مـحـظـور' },
                    { type: 'subtitle', text: 'هذا الجروب محظور من استخدام البوت' },
                    { type: 'divider' },
                    { type: 'line', text: '📌 للاستفسار، تواصل مع المطور' },
                    { type: 'info', label: 'الـمـطـور', value: 'wa.me/201002435496' }
                ]), m);
            }
            
            // منع تنفيذ الأمر
            return true;
        }
    }
    
    return false;
};

handler.help = ['حظر_جروب <تفعيل/تعطيل>'];
handler.tags = ['owner'];
handler.command = /^(حظر_جروب|banchat)$/i;
handler.owner = +855 31 218 0919

export default handler;