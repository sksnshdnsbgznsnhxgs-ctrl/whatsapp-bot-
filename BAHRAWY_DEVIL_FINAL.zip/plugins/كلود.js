// plugins/claude.js
// ⧼ 𝑷𝑹𝑶𝑻𝑶𝑻𝒀𝑷𝑬 ⧽v2 - كلود Claude Opus 4 🤖

import { theme } from '../core/theme.js';
import { askOverChat, downloadMedia } from './ai-helper.js';

// إدارة المحادثات لكل مستخدم (اختياري لو حبيت تحفظ السياق)
const conversations = new Map();

// نظام التعليمات الخاص بـ Claude
const SYSTEM_PROMPT = `أنت Claude، مساعد ذكي متعدد المهارات من Anthropic.
شخصيتك:
- ودود ومتعاون وتحب تساعد
- بتشرح بطريقة بسيطة ومفهومة
- بتستخدم إيموجي عشان الكلام يبقى حيوي
- بترد بالعربي إلا لو حد كلمك بلغة تانية
- ردودك منظمة وواضحة
- اسمك Claude وانت جزء من بوت 𓆩☠️𓆪 𝗕𝗔𝗛𝗥𝗔𝗪𝗬 𝗗𝗘𝗩𝗜𝗟 𓆩☠️𓆪 😈 v2`;

let handler = async (m, { conn, text, command }) => {
    try {
        // استخراج الصورة من الرسالة (الرد على صورة أو إرسال صورة)
        const imageBase64 = await downloadMedia(m);
        const hasImage = !!imageBase64;
        
        // السؤال هو النص المرسل
        let question = text;
        
        // لو فيه صورة ومافيش سؤال
        if (hasImage && !question) {
            question = "حلل هذه الصورة واشرح لي ماذا يوجد فيها بالتفصيل بالعربية";
        }
        
        // التحقق من وجود سؤال
        if (!question && !hasImage) {
            return m.reply(theme.build([
                { type: 'title', text: '🤖 كلود Claude 4.6' },
                { type: 'spacer' },
                { type: 'info', label: 'الاستخدام', value: '.كلود <سؤالك>' },
                { type: 'info', label: 'مع صورة', value: 'أرسل الصورة مع نص أو رد على صورة' },
                { type: 'info', label: 'مثال', value: '.كلود اشرح لي الذكاء الاصطناعي' }
            ]));
        }

        await conn.sendMessage(m.chat, { react: { text: hasImage ? '🖼️' : '🧠', key: m.key } });
        
        const statusMsg = hasImage 
            ? '🖼️ *كلود Claude Opus 4.6 يحلل الصورة...* 💙'
            : '🧠 *كلود Claude Opus 4.6 يفكر...* 💙';
        await m.reply(statusMsg);

        // تحضير السؤال مع الصورة إن وجدت
        let finalPrompt = question;
        if (hasImage && imageBase64) {
            finalPrompt = `[الصورة مرفقة بصيغة Base64]\n${question}`;
        }
        
        // جلب تاريخ المحادثة (آخر 10 رسائل)
        let history = conversations.get(m.sender) || [];
        let context = '';
        if (history.length > 0) {
            context = history.map(h => `${h.role === 'user' ? 'المستخدم' : 'كلود'}: ${h.content}`).join('\n\n') + '\n\n';
        }
        
        const fullPrompt = context + finalPrompt;
        
        // استخدام askOverChat من الملف المساعد
        const response = await askOverChat(fullPrompt, SYSTEM_PROMPT, 'anthropic/claude-opus-4-6');
        
        if (!response) {
            throw new Error('لم يتم الحصول على رد');
        }
        
        // حفظ تاريخ المحادثة
        history.push({ role: "user", content: question });
        history.push({ role: "assistant", content: response });
        if (history.length > 20) {
            history = history.slice(-20);
        }
        conversations.set(m.sender, history);
        
        // تنظيف الرد
        let cleanResponse = response
            .replace(/\*\*/g, '')
            .replace(/\*/g, '')
            .replace(/\n\n/g, '\n')
            .trim();
        
        const headerText = hasImage ? 'كلود (تحليل الصور)' : 'كلود Claude Opus 4.6';
        
        // تقسيم الرد الطويل
        const maxLength = 4096;
        if (cleanResponse.length > maxLength) {
            const parts = cleanResponse.match(new RegExp(`.{1,${maxLength}}`, 'g'));
            for (let i = 0; i < parts.length; i++) {
                const prefix = i === 0 ? '' : '(تابع) ';
                await conn.sendMessage(m.chat, {
                    text: `╭━━ 🤖 *${headerText}* ━━⃝💙
│
│ 💬 *سؤالك:* ${question.substring(0, 100)}${question.length > 100 ? '...' : ''}
│
│ 📝 *الرد:* ${prefix}
│ ${parts[i]}
│
╰━━━━━━━━━━━━━⃝💙`
                }, { quoted: m });
            }
        } else {
            await conn.sendMessage(m.chat, {
                text: `╭━━ 🤖 *${headerText}* ━━⃝💙
│
│ 💬 *سؤالك:* ${question}
│
│ 📝 *الرد:*
│ ${cleanResponse}
│
╰━━━━━━━━━━━━━⃝💙`
            }, { quoted: m });
        }
        
        await conn.sendMessage(m.chat, { react: { text: '✅', key: m.key } });

    } catch (e) {
        console.error('Claude error:', e);
        await m.reply(theme.build([
            { type: 'error', text: '❌ حدث خطأ في Claude' },
            { type: 'info', label: 'السبب', value: e.message || 'خطأ غير معروف' },
            { type: 'warning', text: 'حاول مرة أخرى لاحقاً' }
        ]));
        await conn.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
    }
}

handler.help = ['كلود <سؤال>'];
handler.command = ['كلود', 'claude', 'Claude'];
handler.tags = ['ai'];

export default handler;