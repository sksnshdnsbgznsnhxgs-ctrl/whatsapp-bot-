import fetch from 'node-fetch'
import { prepareWAMessageMedia } from '@whiskeysockets/baileys'

let handler = async (m, { conn, isAdmin, isOwner, participants }) => {
  
  // رفض العضو العادي بنفس رسالة الـ dfail
  if (!isAdmin && !isOwner) {
    return m.reply(`🜲⃝☠️ *فقط المشرفين يمكنهم استخدام هذا الأمر* 🛡️`)
  }

  await conn.sendMessage(m.chat, { react: { text: '🩸', key: m.key } }).catch(() => {})

  let gifBuffer
  try {
    const gifUrl = 'https://file.garden/aauvg01sjleV_ic1/VID-20260506-WA0258.mp4'
    const res = await fetch(gifUrl)
    gifBuffer = Buffer.from(await res.arrayBuffer())
  } catch (e) {
    console.error('خطأ في جلب الجيف:', e)
  }

  let mentions = participants.map(v => v.id)

  let menuText = `> ꒦꒷𓆩☠️𓆪꒷꒦ ✧ 🜲 𖤐 🜲 ✧ ꒦꒷𓆩☠️𓆪꒷꒦
>
> 🜲⃝☠️ *⧼ 𝑷𝑹𝑶𝑻𝑶𝑻𝒀𝑷𝑬 ⧽ v2*
> 𖤐⃝🩸 *تـم تـفـعـيـل مـنـشـن الـكـل*
>
> ꒷꒦𓂅 ☣️ 𓂅꒦꒷ ✧ 𓆩🩸𓆪 ✧ ꒷꒦𓂅 ☣️ 𓂅꒦꒷
>
> 👁️⃝🩸 *تـم تـوجـيـه الـنـداء إلـى:* ${mentions.length} عـضـو
>
> ☠️⃝🩸 *الـمـطـور:* ༺youssf༻
>
> 𓆩☠️𓆪 *يـجـب الـحـضـور الـفـوري* 𓆩☠️𓆪
>
> ꒦꒷𓆩☣️𓆪꒷꒦ ✧ 🩸 🜲 🩸 ✧ ꒦꒷𓆩☣️𓆪꒷꒦`

  if (gifBuffer) {
    await conn.sendMessage(m.chat, {
      video: gifBuffer,
      gifPlayback: true,
      caption: menuText,
      mentions: mentions
    }, { quoted: m })
  } else {
    await conn.sendMessage(m.chat, {
      text: menuText,
      mentions: mentions
    }, { quoted: m })
  }
}

handler.help = ['منشن']
handler.tags = ['group']
handler.command = /^(منشن|tagall|منشن_الكل|mention)$/i
handler.group = true
handler.admin = true  // دي كمان تضمن إن الأمر للأدمن بس في نظام الـ handler

export default handler