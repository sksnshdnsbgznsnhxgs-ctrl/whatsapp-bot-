// commands/سكرين.js
// ⧼ 𝑷𝑹𝑶𝑻𝑶𝑻𝒀𝑷𝑬 ⧽ v2 - سكرين شوت للمواقع 📸

import { theme } from '../core/theme.js';

let handler = async (m, { conn, text, usedPrefix, command }) => {
  if (!text) {
    return m.reply(theme.build([
      { type: 'title', text: '📸 سـكـريـن شـوت' },
      { type: 'subtitle', text: 'لأي موقع أو صفحة' },
      { type: 'divider' },
      { type: 'info', label: 'الاستخدام', value: `${usedPrefix + command} رابط_الموقع` },
      { type: 'info', label: 'مثال', value: `${usedPrefix + command} google.com` }
    ]));
  }

  let url = text;
  if (!url.startsWith('http')) {
    url = 'https://' + url;
  }

  await m.react('⏳');

  const screenshotUrl = `https://image.thum.io/get/fullpage/${encodeURIComponent(url)}`;

  await m.reply(theme.build([
    { type: 'title', text: '📸 سـكـريـن شـوت' },
    { type: 'info', label: '🌐 الموقع', value: url },
    { type: 'divider' },
    { type: 'info', label: '🔗 رابط الصورة', value: screenshotUrl }
  ]));

  await m.react('✅');
};

handler.help = ['سكرين'];
handler.tags = ['tools'];
handler.command = /^(سكرين|screen|screenshot)$/i;

export default handler;