// plugins/anti-link.js
// ⧼ 𝑷𝑹𝑶𝑻𝑶𝑻𝒀𝑷𝑬 ⧽v2 - نظام منع الروابط 🔗

import { theme } from '../core/theme.js';

// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
// 🔥 أمر التفعيل والتعطيل
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

let handler = async (m, { conn, text, isAdmin, isOwner }) => {

  // التحقق من المجموعة
  if (!m.isGroup) {
    return conn.reply(m.chat, `> ${theme.divider}
> 
> 🜲⃝☠️ *خـطـأ*
> 👁️⃝🩸 *هذا الأمر يعمل فقط في المجموعات*
> 
> ${theme.endDivider}`, m);
  }

  // التحقق من الصلاحيات
  if (!isAdmin && !isOwner) {
    return conn.reply(m.chat, `> ${theme.divider}
> 
> 🜲⃝☠️ *خـطـأ*
> 👁️⃝🩸 *هذا الأمر مخصص للمشرفين فقط*
> 
> ${theme.endDivider}`, m);
  }

  // تهيئة قاعدة البيانات لو مش موجودة
  if (!global.db || !global.db.data) {
    global.db = { data: { chats: {} } };
  }
  if (!global.db.data.chats) global.db.data.chats = {};
  if (!global.db.data.chats[m.chat]) {
    global.db.data.chats[m.chat] = { 
      antiLink: false,
      warnings: {}
    };
  }

  let chat = global.db.data.chats[m.chat];

  // عرض الحالة الحالية
  if (!text) {
    const currentStatus = chat.antiLink ? '🟢 مُفعل' : '🔴 مُعطل';
    return conn.reply(m.chat, `> ${theme.divider}
> 
> 🜲⃝☠️ *نـظـام مـنـع الـروبـط*
> 
> ${theme.smallDivider}
> 
> 👁️⃝🩸 *الـحـالـة:* ${currentStatus}
> 👁️⃝🩸 *الـتـحـذيـرات:* 3 ثم طرد
> 
> ${theme.smallDivider}
> 
> 🜲⃝☠️ *الاسـتـخـدام:* .منع_الروابط تفعيل
> 𖤐⃝🩸 *.منع_الروابط تعطيل*
> 
> ${theme.endDivider}`, m);
  }

  // تفعيل النظام
  if (text === "تفعيل") {
    chat.antiLink = true;
    return conn.reply(m.chat, `> ${theme.divider}
> 
> 🜲⃝☠️ *تـم الـتـفـعـيـل*
> 
> ${theme.smallDivider}
> 
> 👁️⃝🩸 *🔗 نظام منع الروابط*
> 👁️⃝🩸 *الـحـالـة:* 🟢 مُفعلة
> 👁️⃝🩸 *الـتـحـذيـرات:* 3 مخالفات ثم الطرد
> 
> ${theme.endDivider}`, m);
  }

  // تعطيل النظام
  if (text === "تعطيل") {
    chat.antiLink = false;
    return conn.reply(m.chat, `> ${theme.divider}
> 
> 🜲⃝☠️ *تـم الـتـعـطـيـل*
> 
> ${theme.smallDivider}
> 
> 👁️⃝🩸 *تم إيقاف نظام منع الروابط*
> 👁️⃝🩸 *الـحـالـة:* 🔴 مُعطلة
> 
> ${theme.endDivider}`, m);
  }

  return conn.reply(m.chat, `> ${theme.divider}
> 
> 🜲⃝☠️ *خـطـأ*
> 👁️⃝🩸 *استخدم: تفعيل أو تعطيل*
> 
> ${theme.endDivider}`, m);
};

// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
// 🔥 نظام التحذير والطرد التلقائي (بيتشغل قبل أي رسالة)
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

handler.before = async function (m, { conn, isBotAdmin, isAdmin }) {

  // التأكد أن الرسالة في مجموعة
  if (!m.isGroup) return;
  
  // التأكد أن فيه نص
  if (!m.text) return;

  // تهيئة قاعدة البيانات
  if (!global.db || !global.db.data) {
    global.db = { data: { chats: {} } };
  }
  if (!global.db.data.chats) global.db.data.chats = {};
  if (!global.db.data.chats[m.chat]) {
    global.db.data.chats[m.chat] = { 
      antiLink: false,
      warnings: {}
    };
  }

  let chat = global.db.data.chats[m.chat];
  
  // التأكد أن النظام مفعل
  if (!chat.antiLink) return;

  // التأكد أن البوت أدمن عشان يقدر يحذف ويطرد
  if (!isBotAdmin) return;

  // عدم تطبيق النظام على المشرفين
  if (isAdmin) return;

  // التحقق من وجود رابط
  const linkRegex = /(https?:\/\/|www\.|chat\.whatsapp\.com|wa\.me|t\.me|telegram\.me|\.com|\.net|\.org)/i;

  if (linkRegex.test(m.text)) {

    // تهيئة سجل التحذيرات للمستخدم
    if (!chat.warnings) chat.warnings = {};
    if (!chat.warnings[m.sender]) {
      chat.warnings[m.sender] = 0;
    }

    chat.warnings[m.sender]++;

    // حذف الرسالة المخالفة
    try {
      await conn.sendMessage(m.chat, {
        delete: {
          remoteJid: m.chat,
          fromMe: false,
          id: m.key.id,
          participant: m.sender
        }
      });
    } catch (err) {
      console.error('فشل حذف الرسالة:', err);
    }

    // إذا وصل 3 تحذيرات → طرد
    if (chat.warnings[m.sender] >= 3) {

      try {
        await conn.groupParticipantsUpdate(m.chat, [m.sender], "remove");
        
        // حذف سجل التحذيرات بعد الطرد
        delete chat.warnings[m.sender];

        return await conn.reply(m.chat, `> ${theme.divider}
> 
> 🜲⃝☠️ *🚫 تـم طـرد الـعـضـو*
> 
> ${theme.smallDivider}
> 
> 👁️⃝🩸 *السبب:* تكرار إرسال الروابط (3 مخالفات)
> 
> ${theme.endDivider}`, m);
        
      } catch (err) {
        console.error('فشل طرد العضو:', err);
        return await conn.reply(m.chat, `> ${theme.divider}
> 
> 🜲⃝☠️ *خـطـأ*
> 👁️⃝🩸 *فشل طرد العضو، تأكد من صلاحيات البوت*
> 
> ${theme.endDivider}`, m);
      }
    }

    // إرسال تحذير عادي
    const remainingWarnings = 3 - chat.warnings[m.sender];
    return await conn.reply(m.chat, `> ${theme.divider}
> 
> 🜲⃝☠️ *⚠️ تـحـذيـر مـن إرسـال الـروبـط*
> 
> ${theme.smallDivider}
> 
> 👁️⃝🩸 *الـمـخـالـفـة:* ${chat.warnings[m.sender]}/3
> 👁️⃝🩸 *الـتـحـذيـرات الـمـتـبـقـيـة:* ${remainingWarnings}
> 
> ${theme.smallDivider}
> 
> 𓆩🩸𓆪 *يـرجى عـدم إرسـال الـروبـط مـرة أخـرى* 𓆩🩸𓆪
> 
> ${theme.endDivider}`, m);
  }
};

handler.help = ['منع_الروابط <تفعيل/تعطيل>'];
handler.tags = ['group'];
handler.command = /^منع_الروابط$/i;
handler.group = true;
handler.botAdmin = true;
handler.admin = true;

export default handler;