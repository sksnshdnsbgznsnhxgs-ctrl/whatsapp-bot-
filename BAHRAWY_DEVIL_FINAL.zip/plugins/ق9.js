// plugins/q9-images.js
// ⧼ 𝑷𝑹𝑶𝑻𝑶𝑻𝒀𝑷𝑬 ⧽v2 - قسم الصور 🖼️

import { prepareWAMessageMedia, generateWAMessageFromContent, proto } from '@whiskeysockets/baileys';
import fetch from 'node-fetch';
import { theme } from '../core/theme.js';

let handler = async (m, { conn, usedPrefix }) => {
    try {
        await conn.sendMessage(m.chat, { react: { text: '🖼️', key: m.key } });

        const user = await conn.getName(m.sender);
        
        // الصورة الجديدة لقسم الصور
        const imageUrl = 'https://file.garden/aauvg01sjleV_ic1/file_000000003b04720a9ebb9035dafa3498.png';
        
        const imageRes = await fetch(imageUrl);
        const imageBuffer = Buffer.from(await imageRes.arrayBuffer());
        const media = await prepareWAMessageMedia({ image: imageBuffer }, { upload: conn.waUploadToServer });

        let menuText = `*╭━━ 𝐈𝐌𝐀𝐆𝐄𝐒 ━━⃝🖼️*\n`
        menuText += `*│* *『 ❐╎ اتش_دي ⃝🖼️ 』*\n`
        menuText += `*│* *『 ❐╎ بينتريست ⃝📌 』*\n`
        menuText += `*│* *『 ❐╎ صوره ⃝🖼️ 』*\n`
        menuText += `*│* *『 ❐╎ خلفيه ⃝🖼️ 』*\n`
        menuText += `*│* *『 ❐╎ خلفيات ⃝🖼️ 』*\n`
        menuText += `*│* *『 ❐╎ ايديت ⃝🎨 』*\n`
        menuText += `*│* *『 ❐╎ ايديت كوره ⃝⚽ 』*\n`
        menuText += `*│* *『 ❐╎ ايديت سيارات ⃝🚗 』*\n`
        menuText += `*│* *『 ❐╎ ايديت انمي ⃝🎬 』*\n`
        menuText += `*│* *『 ❐╎ كابيلز ⃝💬 』*\n`
        menuText += `*│* *『 ❐╎ تطقيم ⃝🎨 』*\n`
        menuText += `*╰━━━━━━━━━━━━━⃝💜*\n\n`

        menuText += `> 𖤐⃝🖼️ *مرحباً ${user}، هذا قسم الصور والتصميم*`;

        const nativeFlowPayload = {
            body: { text: menuText },
            footer: { text: '⧼ 𝑷𝑹𝑶𝑻𝑶𝑻𝒀𝑷𝑬 ⧽ v2 🖼️' },
            header: {
                hasMediaAttachment: true,
                subtitle: '🖼️ قـسـم الـصـور',
                imageMessage: media.imageMessage
            },
            nativeFlowMessage: {
                buttons: [
                    {
                        name: 'quick_reply',
                        buttonParamsJson: JSON.stringify({
                            display_text: '🔙 الـعـودة للـقـائـمـة',
                            id: '.الاوامر'
                        })
                    },
                    {
                        name: 'quick_reply',
                        buttonParamsJson: JSON.stringify({
                            display_text: '👑 الـمـطـور',
                            id: '.المطور'
                        })
                    }
                ],
                messageParamsJson: JSON.stringify({
                    bottom_sheet: {
                        in_thread_buttons_limit: 1,
                        list_title: "🖼️ قـسـم الـصـور",
                        button_title: "خـيـارات"
                    }
                })
            }
        };

        const interactiveMessage = proto.Message.InteractiveMessage.fromObject(nativeFlowPayload);
        const fkontak = await makeFkontak();
        
        const msg = generateWAMessageFromContent(m.chat, { 
            viewOnceMessage: {
                message: {
                    interactiveMessage: interactiveMessage
                }
            }
        }, { 
            userJid: conn.user.jid, 
            quoted: fkontak 
        });
        
        await conn.relayMessage(m.chat, msg.message, { messageId: msg.key.id });

    } catch (e) {
        console.error('خطأ في قسم الصور:', e);
        await conn.sendMessage(m.chat, { 
            text: theme.build([
                { type: 'error', text: '❌ حدث خطأ في تحميل قسم الصور' },
                { type: 'info', label: 'السبب', value: e.message || 'خطأ غير معروف' }
            ])
        }, { quoted: m });
    }
}

async function makeFkontak() {
    try {
        const res = await fetch('https://file.garden/aauvg01sjleV_ic1/a2075690da240b4d4af5e9affed48bbe.jpg');
        const thumb2 = Buffer.from(await res.arrayBuffer());
        return {
            key: { participants: '0@s.whatsapp.net', remoteJid: 'status@broadcast', fromMe: false, id: 'Halo' },
            message: { locationMessage: { name: '⧼ 𝑷𝑹𝑶𝑻𝑶𝑻𝒀𝑷𝑬 ⧽ v2', jpegThumbnail: thumb2 } },
            participant: '0@s.whatsapp.net'
        };
    } catch {
        return undefined;
    }
}

handler.help = ['ق9'];
handler.tags = ['main'];
handler.command = ['ق9', 'images', 'صور'];

export default handler;