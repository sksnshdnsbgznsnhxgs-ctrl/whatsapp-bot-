// plugins/gemini.js
// ⧼ 𝑷𝑹𝑶𝑻𝑶𝑻𝒀𝑷𝑬 ⧽v2 - جيمني Gemini 🤖

import axios from 'axios';
import { theme } from '../core/theme.js';

// الـ cookies الخاصة بالموقع
const COOKIES = {
    PHPSESSID: '7cf9ce6ce003271839a00f28b6f53edd',
    uDevice: 'notapple',
    g_state: '{"i_l":0,"i_ll":1779487253286,"i_e":{"enable_itp_optimization":0},"i_et":1779487251110}'
};

const cookieString = Object.entries(COOKIES)
    .map(([key, value]) => `${key}=${value}`)
    .join('; ');

// إدارة المحادثات
const conversations = new Map();

class Gemini {
    constructor() {
        this.baseUrl = 'https://minitoolai.com/Gemini/gemini_stream2.php';
        this.headers = {
            'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
            'Origin': 'https://minitoolai.com',
            'Referer': 'https://minitoolai.com/Gemini/',
            'Cookie': cookieString,
            'X-Requested-With': 'XMLHttpRequest'
        };
    }

    async chat(message, conversationId = null) {
        if (!conversationId) {
            conversationId = this.generateConversationId();
        }

        const payload = new URLSearchParams();
        payload.append('message', message);
        payload.append('conversation_id', conversationId);
        payload.append('utoken', '26e003b12f9994bad04bee5ceab35e126fddc29950b06db30cffb70cf946d14e');
        payload.append('model', 'gemini-3.1-flash-lite');

        return new Promise((resolve, reject) => {
            let fullResponse = '';
            let timeout = setTimeout(() => {
                reject(new Error('الوقت انتهى، حاول مرة أخرى'));
            }, 60000);

            axios.post(this.baseUrl, payload.toString(), {
                headers: this.headers,
                responseType: 'stream',
                timeout: 60000
            }).then(response => {
                response.data.on('data', (chunk) => {
                    const lines = chunk.toString().split('\n');
                    for (const line of lines) {
                        if (line.startsWith('data: ')) {
                            try {
                                const jsonStr = line.substring(6);
                                if (jsonStr.trim() === '' || jsonStr === '[DONE]') continue;
                                
                                const data = JSON.parse(jsonStr);
                                
                                if (data.choices?.[0]?.delta?.content) {
                                    fullResponse += data.choices[0].delta.content;
                                }
                            } catch (e) {
                                // تجاهل أخطاء الـ JSON
                            }
                        }
                    }
                });

                response.data.on('end', () => {
                    clearTimeout(timeout);
                    if (fullResponse) {
                        resolve({
                            text: fullResponse.trim(),
                            conversationId: conversationId
                        });
                    } else {
                        reject(new Error('لم يتم الحصول على رد'));
                    }
                });

                response.data.on('error', (err) => {
                    clearTimeout(timeout);
                    reject(err);
                });
            }).catch(error => {
                clearTimeout(timeout);
                reject(error);
            });
        });
    }

    generateConversationId() {
        return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) {
            const r = Math.random() * 16 | 0;
            const v = c === 'x' ? r : (r & 0x3 | 0x8);
            return v.toString(16);
        });
    }
}

let handler = async (m, { conn, text }) => {
    try {
        if (!text) {
            return m.reply(theme.build([
                { type: 'title', text: '🤖 جيمني Gemini' },
                { type: 'spacer' },
                { type: 'info', label: 'الاستخدام', value: '.جيمني <سؤالك>' },
                { type: 'info', label: 'مثال', value: '.جيمني من أنت؟' }
            ]));
        }

        await conn.sendMessage(m.chat, { react: { text: '🧠', key: m.key } });
        await m.reply('🧠 *جيمني Gemini يفكر...* 💙');

        const gemini = new Gemini();
        
        // جلب conversation_id القديم إن وجد
        let conversationId = conversations.get(m.sender);
        
        const result = await gemini.chat(text, conversationId);
        
        // حفظ conversation_id للمرة القادمة
        if (result.conversationId) {
            conversations.set(m.sender, result.conversationId);
        }
        
        // تنظيف الرد
        let cleanResponse = result.text.trim();
        
        // تقسيم الرد الطويل
        const maxLength = 4096;
        if (cleanResponse.length > maxLength) {
            const parts = cleanResponse.match(new RegExp(`.{1,${maxLength}}`, 'g'));
            for (let i = 0; i < parts.length; i++) {
                const prefix = i === 0 ? '' : '(تابع) ';
                await conn.sendMessage(m.chat, {
                    text: `╭━━ 🤖 *جيمني Gemini* ━━⃝💙
│
│ 💬 *سؤالك:* ${text.substring(0, 100)}${text.length > 100 ? '...' : ''}
│
│ 📝 *الرد:* ${prefix}
│ ${parts[i]}
│
╰━━━━━━━━━━━━━⃝💙`
                }, { quoted: m });
            }
        } else {
            await conn.sendMessage(m.chat, {
                text: `╭━━ 🤖 *جيمني Gemini* ━━⃝💙
│
│ 💬 *سؤالك:* ${text}
│
│ 📝 *الرد:*
│ ${cleanResponse}
│
╰━━━━━━━━━━━━━⃝💙`
            }, { quoted: m });
        }
        
        await conn.sendMessage(m.chat, { react: { text: '✅', key: m.key } });

    } catch (e) {
        console.error('Gemini error:', e);
        await m.reply(theme.build([
            { type: 'error', text: '❌ حدث خطأ في جيمني' },
            { type: 'info', label: 'السبب', value: e.message || 'خطأ غير معروف' },
            { type: 'warning', text: 'حاول مرة أخرى لاحقاً' }
        ]));
        await conn.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
    }
}

handler.help = ['جيمني <سؤال>'];
handler.command = ['جيمني', 'gemini'];
handler.tags = ['ai'];

export default handler;