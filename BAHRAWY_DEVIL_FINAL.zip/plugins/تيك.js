import axios from "axios";
import { theme } from '../core/theme.js';

let handler = async (m, { conn, args }) => {
  if (!args[0]) {
    const responseText = `> ${theme.divider}
> 
> 🜲⃝☠️ *خـطـأ*
> 👁️⃝🩸 *الرجاء إرسال رابط تيك توك*
> 
> ${theme.smallDivider}
> 
> 📎 *مثال:* 
> .تيك https://vm.tiktok.com/xxxxx
> 
> ${theme.endDivider}`;
    return m.reply(responseText);
  }

  let url = args[0];
  
  if (!/tiktok|douyin|vm\.tiktok|vt\.tiktok/i.test(url)) {
    const errorText = `> ${theme.divider}
> 
> 🜲⃝☠️ *خـطـأ*
> 👁️⃝🩸 *الرابط غير صالح! الرجاء إدخال رابط تيك توك صحيح*
> 
> ${theme.endDivider}`;
    return m.reply(errorText);
  }

  await conn.sendMessage(m.chat, { react: { text: "⏳", key: m.key } });

  try {
    let result = await Tiktok(url);
    if (!result || result.code !== 0) {
      throw new Error("No video found");
    }

    let { title, play, hdplay, music, cover, author, duration, digg_count, comment_count, share_count } = result.data;
    
    let videoUrl = hdplay || play;
    
    // تخزين الجلسة مؤقتاً
    global.tiktokSession = {
      sender: m.sender,
      videoUrl: videoUrl,
      musicUrl: music,
      title: title || 'فيديو تيك توك',
      author: author?.nickname || 'غير معروف',
      username: author?.unique_id || '',
      duration: duration || 0,
      likes: digg_count || 0,
      comments: comment_count || 0,
      shares: share_count || 0,
      cover: cover,
      timestamp: Date.now()
    };

    // نص الزخرفة للكابشن
    const caption = `> ${theme.divider}
> 
> 🜲⃝☠️ *تـيـك تـوك*
> 𖤐⃝🩸 *${title?.substring(0, 40) || 'فيديو تيك توك'}*
> 
> ${theme.smallDivider}
> 
> 👁️⃝🩸 *المنشئ:* ${author?.nickname || 'غير معروف'} (@${author?.unique_id || '?'})
> 👁️⃝🩸 *المدة:* ${duration} ثانية
> 👁️⃝🩸 *الإعجابات:* ${formatNum(digg_count)}
> 👁️⃝🩸 *التعليقات:* ${formatNum(comment_count)}
> 👁️⃝🩸 *المشاركات:* ${formatNum(share_count)}
> 
> ${theme.smallDivider}
> 
> ✓⃝ *اختر نوع التحميل من الأزرار أدناه*
> 
> ${theme.endDivider}`;

    // الأزرار
    const buttons = [
      { buttonId: `tt_video_${m.sender}`, buttonText: { displayText: '🎬 فيديو' }, type: 1 },
      { buttonId: `tt_audio_${m.sender}`, buttonText: { displayText: '🎵 صوت فقط' }, type: 1 }
    ];

    // إرسال الصورة + الأزرار
    await conn.sendMessage(m.chat, {
      image: { url: cover },
      caption: caption,
      footer: '⧼ 𝑷𝑹𝑶𝑻𝑶𝑻𝒀𝑷𝑬 ⧽ v2',
      buttons: buttons,
      headerType: 1
    }, { quoted: m });

    await conn.sendMessage(m.chat, { react: { text: "✅", key: m.key } });

    // حذف الجلسة بعد 5 دقائق
    setTimeout(() => {
      if (global.tiktokSession?.sender === m.sender) {
        delete global.tiktokSession;
      }
    }, 5 * 60 * 1000);

  } catch (error) {
    console.error("TikTok API Error:", error);
    await conn.sendMessage(m.chat, { react: { text: "❌", key: m.key } });
    const errorText = `> ${theme.divider}
> 
> 🜲⃝☠️ *خـطـأ*
> 👁️⃝🩸 *فشل في تحميل الفيديو*
> 
> ${theme.smallDivider}
> 
> ⚠️ *تأكد من صحة الرابط وحاول مرة أخرى*
> 
> ${theme.endDivider}`;
    m.reply(errorText);
  }
};

// معالج الأزرار
handler.before = async function (m, { conn }) {
  if (!m.message?.buttonsResponseMessage) return;

  const buttonId = m.message.buttonsResponseMessage.selectedButtonId;
  if (!buttonId) return;

  const isVideo = buttonId.includes('video');
  const isAudio = buttonId.includes('audio');
  
  if (!isVideo && !isAudio) return;

  const session = global.tiktokSession;
  if (!session || session.sender !== m.sender) {
    const expiredText = `> ${theme.divider}
> 
> 🜲⃝☠️ *انـتـهـت الـجـلـسـة*
> 👁️⃝🩸 *الرجاء إعادة إرسال رابط التيك توك مرة أخرى*
> 
> ${theme.endDivider}`;
    await conn.reply(m.chat, expiredText, m);
    return;
  }

  await conn.sendMessage(m.chat, { react: { text: "⏳", key: m.key } }).catch(() => {});

  try {
    if (isAudio) {
      if (!session.musicUrl) {
        await m.reply(`> ${theme.divider}\n>\n> 🜲⃝☠️ *خـطـأ*\n> 👁️⃝🩸 *لا يوجد صوت متاح لهذا الفيديو*\n>\n> ${theme.endDivider}`);
        return;
      }
      
      const audioCaption = `> ${theme.divider}
> 
> 🜲⃝☠️ *تـم الـتـحـمـيـل*
> 𖤐⃝🩸 *صوت تيك توك*
> 
> ${theme.endDivider}`;
      
      await conn.sendMessage(m.chat, {
        audio: { url: session.musicUrl },
        mimetype: 'audio/mpeg',
        ptt: false
      }, { quoted: m });
      
    } else {
      const videoCaption = `> ${theme.divider}
> 
> 🜲⃝☠️ *تـم الـتـحـمـيـل*
> 𖤐⃝🩸 *فيديو تيك توك*
> 
> ${theme.endDivider}`;
      
      await conn.sendMessage(m.chat, {
        video: { url: session.videoUrl },
        caption: videoCaption,
        mimetype: 'video/mp4'
      }, { quoted: m });
    }

    await conn.sendMessage(m.chat, { react: { text: "✅", key: m.key } }).catch(() => {});
    delete global.tiktokSession;

  } catch (err) {
    console.error('[Button Error]', err);
    const errorText = `> ${theme.divider}
> 
> 🜲⃝☠️ *خـطـأ*
> 👁️⃝🩸 *حدث خطأ أثناء التحميل*
> 
> ${theme.endDivider}`;
    await conn.reply(m.chat, errorText, m);
  }
};

const Tiktok = async (url) => {
  try {
    let params = new URLSearchParams();
    params.append("url", url);

    let { data } = await axios.post("https://tikwm.com/api/", params, {
      headers: {
        "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8",
        Cookie: "current_language=en",
        "User-Agent": "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/116.0.0.0 Mobile Safari/537.36",
      },
    });

    if (!data || typeof data.code !== "number") {
      throw new Error("Invalid API response");
    }

    return data;
  } catch (error) {
    throw new Error(`Tiktok API Error: ${error.message}`);
  }
};

function formatNum(n) {
  if (!n) return "0";
  if (n >= 1000000) return (n / 1000000).toFixed(1) + "M";
  if (n >= 1000) return (n / 1000).toFixed(1) + "K";
  return n.toString();
}

handler.help = ["تيك <رابط>"];
handler.tags = ["downloader"];
handler.command = /^(تيك|tik|تيكتوك|tiktok)$/i;

export default handler;