import fetch from "node-fetch";
import { theme } from '../core/theme.js';
import { generateWAMessageFromContent, proto } from '@whiskeysockets/baileys';

let CLIENT_IDS = [
  'DzA2vRpkKqKVM37Lh9O3XPIJwTpL4U9M',
  'a3e059563d7fd3372b49b37f00a00bcf',
  'iZIs9mchVcX5lhVRyQGGAYlNPVldzAoX',
  'KKzJxmw11tYpCs6T24P4uUYhqmjalG6M',
  'ZbE1zOjMvRkXpL2qW8yN5cF7uA3sD6gH9jK',
];

async function searchSoundCloud(query, limit = 10) {
  const headers = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
    'Accept': 'application/json',
    'Accept-Language': 'en-US,en;q=0.9',
    'Origin': 'https://soundcloud.com',
    'Referer': 'https://soundcloud.com/'
  };

  for (const cid of CLIENT_IDS) {
    try {
      const url = `https://api-v2.soundcloud.com/search?q=${encodeURIComponent(query)}&client_id=${cid}&limit=${limit}&variant_ids=`;
      const res = await fetch(url, { headers });
      if (res.status === 429) continue;
      if (!res.ok) continue;
      const data = await res.json();
      const tracks = data?.collection?.filter(item => item.kind === 'track') || [];
      if (tracks.length > 0) return tracks.slice(0, limit);
    } catch (err) {
      console.log(`Search error: ${err.message}`);
    }
  }
  return [];
}

async function downloadSoundCloud(trackUrl) {
  for (const cid of CLIENT_IDS) {
    try {
      const resolveUrl = `https://api-v2.soundcloud.com/resolve?url=${encodeURIComponent(trackUrl)}&client_id=${cid}`;
      const res = await fetch(resolveUrl, {
        headers: { 'User-Agent': 'Mozilla/5.0', 'Accept': 'application/json' }
      });
      if (res.status === 429) continue;
      if (!res.ok) continue;
      const track = await res.json();
      if (!track?.media?.transcodings?.length) continue;
      
      const tc = track.media.transcodings;
      const pick = tc.find(t => t.format?.protocol === 'progressive') || tc[0];
      if (!pick?.url) continue;
      
      const sep = pick.url.includes('?') ? '&' : '?';
      const streamRes = await fetch(`${pick.url}${sep}client_id=${cid}`, {
        headers: { 'User-Agent': 'Mozilla/5.0', 'Accept': 'application/json' }
      });
      if (streamRes.status === 429) continue;
      if (!streamRes.ok) continue;
      
      const streamData = await streamRes.json();
      if (!streamData?.url) continue;
      
      return {
        audioUrl: streamData.url,
        title: track.title || 'SoundCloud',
        thumb: track.artwork_url ? track.artwork_url.replace('large', 't500x500') : null,
      };
    } catch (err) {
      console.log(`Download error: ${err.message}`);
    }
  }
  throw new Error('فشل التحميل');
}

async function makeFkontak() {
  try {
    const res = await fetch('https://file.garden/aauvg01sjleV_ic1/2b8bcdfe601fc2f648d23afe81a456fa.jpg');
    const thumb2 = Buffer.from(await res.arrayBuffer());
    return {
      key: { participants: '0@s.whatsapp.net', remoteJid: 'status@broadcast', fromMe: false, id: 'Halo' },
      message: { locationMessage: { name: '⧼ 𝑷𝑹𝑶𝑻𝑶𝑻𝒀𝑷𝑬 ⧽ v2', jpegThumbnail: thumb2 } },
      participant: '0@s.whatsapp.net'
    };
  } catch {
    return undefined;
  }
}

let handler = async (m, { conn, text, usedPrefix, command }) => {

  const react = async (emoji) => {
    try { await conn.sendMessage(m.chat, { react: { text: emoji, key: m.key } }); } catch {}
  };

  if (text && text.includes('soundcloud.com')) {
    react('⏳');
    try {
      const result = await downloadSoundCloud(text.trim());
      const caption = `> ${theme.divider}\n> \n> 🜲⃝☠️ *تـم الـتـحـمـيـل*\n> 𖤐⃝🩸 *${result.title.substring(0, 50)}*\n> \n> ${theme.endDivider}`;
      await conn.sendMessage(m.chat, {
        audio: { url: result.audioUrl },
        mimetype: 'audio/mpeg',
        ptt: false
      }, { quoted: m });
      react('✅');
    } catch (e) {
      react('❌');
      m.reply(`❌ فشل التحميل: ${e.message}`);
    }
    return;
  }

  if (!text) {
    const helpText = `> ${theme.divider}\n> \n> 🜲⃝☠️ *سـاونـد كـلـاود*\n> 𖤐⃝🩸 *تحميل الأغاني من SoundCloud*\n> \n> ${theme.smallDivider}\n> \n> 👁️⃝🩸 *الاستخدام:*\n> ${usedPrefix + command} <اسم الأغنية>\n> \n> 👁️⃝🩸 *مثال:*\n> ${usedPrefix + command} faded alan walker\n> \n> ${theme.endDivider}`;
    return m.reply(helpText);
  }

  react('🔍');
  await m.reply(`🔍 *جاري البحث عن:* ${text}...`);

  try {
    const tracks = await searchSoundCloud(text, 10);
    if (!tracks.length) {
      react('❌');
      return m.reply(`❌ لا توجد نتائج للبحث: ${text}`);
    }

    // بناء القائمة بنفس طريقة المنيو
    const sections = [];
    const rows = [];
    
    for (let i = 0; i < tracks.length; i++) {
      const track = tracks[i];
      const artistName = track.user?.username || track.user?.full_name || 'Unknown';
      const duration = Math.floor(track.duration / 60000) + ':' + Math.floor((track.duration % 60000) / 1000).toString().padStart(2, '0');
      const title = track.title.length > 35 ? track.title.substring(0, 32) + '...' : track.title;
      
      rows.push({
        title: `${i + 1}. ${title}`,
        description: `👤 ${artistName} | ⏱️ ${duration}`,
        id: `.ساوند_تحميل ${track.permalink_url}`
      });
    }
    
    sections.push({
      title: "🎵 نتائج البحث",
      rows: rows
    });

    const nativeFlowPayload = {
      body: { text: `> ${theme.divider}\n> \n> 🜲⃝☠️ *نـتـائـج الـبـحـث*\n> 𖤐⃝🩸 *عن: ${text}*\n> \n> ${theme.smallDivider}\n> \n> 👁️⃝🩸 *تم العثور على ${tracks.length} نتيجة*\n> \n> ${theme.smallDivider}\n> \n> ✓⃝ *اختر الأغنية من القائمة أدناه*\n> \n> ${theme.endDivider}` },
      footer: { text: '⧼ 𝑷𝑹𝑶𝑻𝑶𝑻𝒀𝑷𝑬 ⧽ v2' },
      nativeFlowMessage: {
        buttons: [
          {
            name: 'single_select',
            buttonParamsJson: JSON.stringify({
              title: "🎵 اختر الأغنية",
              sections: sections
            })
          }
        ],
        messageParamsJson: JSON.stringify({
          bottom_sheet: {
            in_thread_buttons_limit: 1,
            list_title: "🎵 قائمة الأغاني",
            button_title: "🎵 عرض النتائج"
          }
        })
      }
    };

    const interactiveMessage = proto.Message.InteractiveMessage.fromObject(nativeFlowPayload);
    const fkontak = await makeFkontak();
    const msg = generateWAMessageFromContent(m.chat, { interactiveMessage }, {
      userJid: conn.user.jid,
      quoted: fkontak
    });

    await conn.relayMessage(m.chat, msg.message, { messageId: msg.key.id });
    react('✅');

  } catch (e) {
    console.error(e);
    react('❌');
    m.reply(`❌ فشل البحث: ${e.message}`);
  }
};

// معالج الأزرار
handler.before = async function (m, { conn }) {
  if (!m.text) return;
  
  if (m.text.startsWith('.ساوند_تحميل')) {
    const trackUrl = m.text.replace('.ساوند_تحميل', '').trim();
    if (trackUrl) {
      await conn.sendMessage(m.chat, { react: { text: '⏳', key: m.key } }).catch(() => {});
      try {
        const result = await downloadSoundCloud(trackUrl);
        const caption = `> ${theme.divider}\n> \n> 🜲⃝☠️ *تـم الـتـحـمـيـل*\n> 𖤐⃝🩸 *${result.title.substring(0, 50)}*\n> \n> ${theme.endDivider}`;
        await conn.sendMessage(m.chat, {
          audio: { url: result.audioUrl },
          mimetype: 'audio/mpeg',
          ptt: false
        }, { quoted: m });
        await conn.sendMessage(m.chat, { react: { text: '✅', key: m.key } }).catch(() => {});
      } catch (e) {
        await conn.sendMessage(m.chat, { react: { text: '❌', key: m.key } }).catch(() => {});
        m.reply(`❌ فشل التحميل: ${e.message}`);
      }
      return true;
    }
  }
  return;
};

handler.help = ['ساوند <اسم>'];
handler.tags = ['downloader'];
handler.command = /^(اغنيه|soundcloud|sc)$/i;

export default handler;