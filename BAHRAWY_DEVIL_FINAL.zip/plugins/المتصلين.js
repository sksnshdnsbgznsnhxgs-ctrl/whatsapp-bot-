// امر المتصلين - عرض الأعضاء النشطاء (الذين أرسلوا رسائل مؤخراً)
// يعتمد على الرسائل المخزنة في ذاكرة البوت

let handler = async (m, { conn, args }) => {
  try {
    // تحديد ID المجموعة
    let id = args?.[0]?.match(/\d+\-\d+@g.us/) || m.chat;
    
    // إذا لم تكن مجموعة، اخرج
    if (!id.endsWith('@g.us')) {
      return m.reply('❌ هذا الأمر يستخدم فقط في المجموعات')
    }

    await conn.sendMessage(m.chat, { react: { text: '🌐', key: m.key } });

    // جلب جميع الرسائل المخزنة لهذه المجموعة
    const messages = conn.chats[id]?.messages || {}
    
    // استخراج المشاركين الفريدين من الرسائل
    const participantsSet = new Set()
    for (let msg of Object.values(messages)) {
      if (msg.key?.participant) {
        participantsSet.add(msg.key.participant)
      }
    }
    
    const onlineList = Array.from(participantsSet)
      .sort((a, b) => a.split('@')[0].localeCompare(b.split('@')[0]))
      .map((k, i) => `*🐥┆${i + 1}. @${k.split('@')[0]}*`)
      .join('\n') || '*🐦┆✦ لا يوجد أعضاء نشطاء حالياً*'

    let teks = `> ꒦꒷𓆩🌐𓆪꒷꒦
> 
> 🜲⃝☠️ *قـائـمـة الأعـضـاء الـنـشـطـاء*
> 👁️⃝🩸 *الذين أرسلوا رسائل منذ تشغيل البوت*
> 
> ${onlineList}
> 
> ꒦꒷𓆩☣️𓆪꒷꒦ ✧ 🩸 𖤐 🜲 ✧ ꒦꒷𓆩☣️𓆪꒷꒦
> 
> 𓆩⧼ 𝑷𝑹𝑶𝑻𝑶𝑻𝒀𝑷𝑬 ⧽ v2 𓆪`

    await conn.sendMessage(m.chat, { text: teks, mentions: Array.from(participantsSet) }, { quoted: m })
    await conn.sendMessage(m.chat, { react: { text: '✅', key: m.key } })

  } catch (e) {
    console.error(e)
    m.reply(`> ❌ *حدث خطأ أثناء جلب الأعضاء النشطاء*`)
  }
}

handler.help = ['المتصلين']
handler.tags = ['group']
handler.command = /^(المتصلين|النشطين|active)$/i
handler.group = true

export default handler