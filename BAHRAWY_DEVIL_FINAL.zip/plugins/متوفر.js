// plugins/motawer.js
// ⧼ 𝑷𝑹𝑶𝑻𝑶𝑻𝒀𝑷𝑬 ⧽ v2 - التحقق من توفر اللقب 👥

let handler = async (m, { conn, text }) => {
    try {
        const groupId = m.chat;
        const name = text?.trim();

        if (!name) {
            return m.reply(`✍️ *يرجى إدخال اللقب المراد التحقق منه*\nمثال: .متوفر الأسطورة`);
        }

        // التأكد من وجود قاعدة البيانات
        if (!global.db?.data?.users) {
            return m.reply(`❌ قاعدة البيانات غير جاهزة`);
        }

        const users = global.db.data.users;
        let taken = false;
        let owner = +855 31 218 0919

        for (let key in users) {
            const user = users[key];
            if (user.groups?.[groupId]?.name?.toLowerCase() === name.toLowerCase()) {
                taken = true;
                owner = +855 31 218 0919
                break;
            }
        }

        if (taken) {
            let ownerName = البحراوي'@')[0];
            let msg = `╭━━ 👥 *اللقب غير متاح* ━━⃝💙
│
│ ❌ *اللقب "${name}" محجوز بالفعل*
│ 👤 *بواسطة:* ${ownerName}
│
╰━━━━━━━━━━━━━⃝💙`;
            await conn.sendMessage(m.chat, { text: msg }, { quoted: m });
        } else {
            let msg = `╭━━ 👥 *اللقب متاح* ━━⃝💙
│
│ ✅ *اللقب "${name}" متاح للحجز*
│ 💡 *للحجز:* .حجز_لقب ${name}
│
╰━━━━━━━━━━━━━⃝💙`;
            await conn.sendMessage(m.chat, { text: msg }, { quoted: m });
        }

    } catch (err) {
        console.error('متوفر error:', err);
        await m.reply(`❌ حدث خطأ: ${err.message || err}`);
    }
};

handler.help = ['متوفر <لقب>'];
handler.tags = ['unions'];
handler.command = /^(متوفر|available|check)$/i;
handler.group = true;

export default handler;