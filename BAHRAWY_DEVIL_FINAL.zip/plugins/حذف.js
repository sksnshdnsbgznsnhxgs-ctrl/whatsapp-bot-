// امر حذف - يحذف أي رسالة ترد عليها

let handler = async (m, { conn, isAdmin, isROwner }) => {
  if (!m.quoted) return

  if (m.isGroup && !isAdmin && !isROwner) return

  try {
    const q = m.quoted

    // ── بناء المفتاح الصحيح ─────────────────────────────────────────────────
    const deleteKey = {
      remoteJid: m.chat,
      fromMe:    q.fromMe ?? q.isSelf ?? (q.sender === conn.user.jid),
      id:        q.id ?? q.key?.id,
      // participant مطلوب في الجروب لو الرسالة مش من البوت
      ...(m.isGroup && { participant: q.sender ?? q.participant ?? q.key?.participant })
    }

    if (!deleteKey.id) {
      console.log('[DEL] مفتاح الرسالة غير صالح')
      return
    }

    await conn.sendMessage(m.chat, { delete: deleteKey })

  } catch (e) {
    console.error('[DEL] فشل الحذف:', e.message)
  }
}

handler.command = /^(حذف|مسح|delete|del)$/i
export default handler
