let handler = async (m, { conn, text, usedPrefix, command }) => {
  if (!m.isGroup) {
    return m.reply('*⚠️ هـذا الأمـر يـعـمـل فـقـط فـي الـمـجـمـوعـات*')
  }

  if (!text) {
    return m.reply(`*⚠️ يـرجـى كـتـابـة نـص الـحـالـة*\n\n*📌 مـثـال:*\n${usedPrefix + command} مرحبا`)
  }

  try {
    await conn.sendMessage(m.chat, { 
      groupStatusMessage: { 
        text: text, 
        backgroundColor: '#000000', 
        font: 1 
      } 
    }, { quoted: m })

    await m.reply('*✅ تـم رفـع الـحـالـة لـلـمـجـمـوعـة*')
  } catch (e) {
    console.error(e)
    await m.reply('*❌ فـشـل رفـع الـحـالـة*\n*⚠️ تـأكـد أن الـمـيـزة مـتـاحـة لـرقـم الـبـوت*')
  }
}

handler.command = ['رفع-حالة-جروب', 'حاله', 'status']
handler.group = true

export default handler