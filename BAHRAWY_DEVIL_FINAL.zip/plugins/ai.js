// plugins/ai.js
// ⧼ 𝑷𝑹𝑶𝑻𝑶𝑻𝒀𝑷𝑬 ⧽v2 - الذكاء الاصطناعي (Qwen 3-32B) 🤖

import axios from 'axios';
import { theme } from '../core/theme.js';
import { downloadMedia } from './ai-helper.js';

// Groq API Key
const GROQ_API_KEY = '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';

// إدارة المحادثات لكل مستخدم
const conversations = new Map();

class QwenAI {
    constructor() {
        this.baseUrl = 'https://api.groq.com/openai/v1/chat/completions';
        this.model = 'qwen/qwen3-32b';
    }

    async chat(message, imageBase64, history = []) {
        try {
            // بناء الرسائل
            const messages = [
                {
                    role: "system",
                    content: "أنت مساعد ذكي ومفيد اسمك Qwen. تتحدث بالعربية بشكل طبيعي. ردودك منظمة وواضحة. تساعد المستخدمين في أي سؤال."
                }
            ];
            
            // إضافة تاريخ المحادثة
            for (const msg of history) {
                messages.push({
                    role: msg.role === 'user' ? 'user' : 'assistant',
                    content: msg.content
                });
            }
            
            // إضافة الرسالة الحالية
            let userMessage = message;
            if (imageBase64) {
                userMessage = `[صورة مرفقة] ${message || 'حلل هذه الصورة وصفها'}`;
            }
            messages.push({
                role: "user",
                content: userMessage
            });
            
            const payload = {
                model: this.model,
                messages: messages,
                temperature: 0.7,
                max_tokens: 4096,
                top_p: 0.95
            };
            
            const response = await axios.post(this.baseUrl, payload, {
                headers: {
                    'Authorization': `Bearer ${GROQ_API_KEY}`,
                    'Content-Type': 'application/json'
                },
                timeout: 60000
            });
            
            const text = response.data?.choices?.[0]?.message?.content;
            
            if (!text) {
                throw new Error('لم يتم الحصول على رد');
            }
            
            return text;
            
        } catch (error) {
            console.error('Qwen API error:', error.response?.data || error.message);
            
            if (error.response?.status === 401) {
                throw new Error('مفتاح API غير صالح');
            }
            if (error.response?.status === 429) {
                throw new Error('تم تجاوز الحد المسموح، حاول مرة أخرى لاحقاً');
            }
            
            throw new Error(error.response?.data?.error?.message || error.message);
        }
    }
}

let handler = async (m, { conn, text }) => {
    try {
        // استخراج الصورة من الرسالة
        const imageBase64 = await downloadMedia(m);
        const hasImage = !!imageBase64;
        
        // السؤال هو النص المرسل
        let question = text;
        
        // لو فيه صورة ومافيش سؤال
        if (hasImage && !question) {
            question = "حلل هذه الصورة واشرح لي ماذا يوجد فيها بالتفصيل بالعربية";
        }
        
        // التحقق من وجود سؤال
        if (!question && !hasImage) {
            return m.reply(theme.build([
                { type: 'title', text: '🤖 Qwen 3-32B' },
                { type: 'spacer' },
                { type: 'info', label: 'الاستخدام', value: '.ai <سؤالك>' },
                { type: 'info', label: 'مع صورة', value: 'أرسل الصورة مع نص أو رد على صورة' },
                { type: 'info', label: 'مثال', value: '.ai من أنت؟' }
            ]));
        }

        await conn.sendMessage(m.chat, { react: { text: hasImage ? '🖼️' : '🧠', key: m.key } });
        
        const statusMsg = hasImage 
            ? '🖼️ *Qwen يحلل الصورة...* 💙'
            : '🧠 *Qwen 3-32B يفكر...* 💙';
        await m.reply(statusMsg);

        const qwen = new QwenAI();
        
        // جلب تاريخ المحادثة
        let history = conversations.get(m.sender) || [];
        
        const response = await qwen.chat(question, imageBase64, history);
        
        if (!response) {
            throw new Error('لم يتم الحصول على رد');
        }
        
        // حفظ تاريخ المحادثة
        history.push({ role: "user", content: question });
        history.push({ role: "assistant", content: response });
        if (history.length > 20) {
            history = history.slice(-20);
        }
        conversations.set(m.sender, history);
        
        // تنظيف الرد
        let cleanResponse = response
            .replace(/\*\*/g, '')
            .replace(/\*/g, '')
            .replace(/\n\n/g, '\n')
            .trim();
        
        const headerText = hasImage ? 'Qwen (تحليل الصور)' : 'Qwen 3-32B';
        
        // تقسيم الرد الطويل
        const maxLength = 4096;
        if (cleanResponse.length > maxLength) {
            const parts = cleanResponse.match(new RegExp(`.{1,${maxLength}}`, 'g'));
            for (let i = 0; i < parts.length; i++) {
                const prefix = i === 0 ? '' : '(تابع) ';
                await conn.sendMessage(m.chat, {
                    text: `╭━━ 🤖 *${headerText}* ━━⃝💙
│
│ 💬 *سؤالك:* ${question.substring(0, 100)}${question.length > 100 ? '...' : ''}
│
│ 📝 *الرد:* ${prefix}
│ ${parts[i]}
│
╰━━━━━━━━━━━━━⃝💙`
                }, { quoted: m });
            }
        } else {
            await conn.sendMessage(m.chat, {
                text: `╭━━ 🤖 *${headerText}* ━━⃝💙
│
│ 💬 *سؤالك:* ${question}
│
│ 📝 *الرد:*
│ ${cleanResponse}
│
╰━━━━━━━━━━━━━⃝💙`
            }, { quoted: m });
        }
        
        await conn.sendMessage(m.chat, { react: { text: '✅', key: m.key } });

    } catch (e) {
        console.error('AI error:', e);
        await m.reply(theme.build([
            { type: 'error', text: '❌ حدث خطأ' },
            { type: 'info', label: 'السبب', value: e.message || 'خطأ غير معروف' },
            { type: 'warning', text: 'حاول مرة أخرى لاحقاً' }
        ]));
        await conn.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
    }
}

handler.help = ['ai <سؤال>'];
handler.command = ['ai', 'AI', 'ذكاء'];
handler.tags = ['ai'];

export default handler;