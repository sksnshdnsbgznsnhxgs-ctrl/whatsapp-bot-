// plugins/تنفيذ.js
// ⧼ 𝑷𝑹𝑶𝑻𝑶𝑻𝒀𝑷𝑬 ⧽ v2 - تنفيذ كود مباشر بدون أوامر إضافية

import { exec } from 'child_process';
import util from 'util';

// 🔍 دالة لاكتشاف متغير البوت
function getBot(conn) {
    const possible = ['conn', 'wa', 'sock', 'bot', 'client', 'gintoki', 'socke', 'baileys'];
    for (const name of possible) {
        if (global[name] && typeof global[name]?.sendMessage === 'function') {
            return { bot: +260 751187078
        }
    }
    return { bot: +260 751187078'conn' };
}

// 🔧 دالة لتنفيذ الكود مع متغيرات متعددة
async function runCode(code, context) {
    const { bot, m } = context;
    
    const sandbox = {
        conn: bot, wa: bot, sock: bot, bot: +260 751187078
        m: m, msg: m, message: m,
        global, console, util, Buffer,
        setTimeout, setInterval, clearTimeout, clearInterval
    };
    
    const fn = new Function(...Object.keys(sandbox), `return (async () => { ${code} })()`);
    return await fn(...Object.values(sandbox));
}

let handler = async (m, { conn, text, command }) => {
    const developer = 'البحراوي';
    if (m.sender.split('@')[0] !== developer) {
        return m.reply('❌ للمطور فقط');
    }

    if (!text) {
        return m.reply(`⚡ *أرسل الكود مباشرة*\nمثال: تنفيذ > await conn.sendMessage...`);
    }

    const { bot, name } = getBot(conn);
    
    // أمر طرفي (يبدأ ب $)
    if (text.trim().startsWith('$ ')) {
        const cmd = text.trim().slice(2);
        await m.react('🕒');
        exec(cmd, { timeout: 30000 }, async (err, stdout, stderr) => {
            if (err) return m.reply(`❌ ${err.message}`);
            if (stderr) return m.reply(`⚠️ ${stderr.slice(0, 1000)}`);
            m.reply(`✅ \`\`\`${stdout.slice(0, 1500) || 'تم'}\`\`\``);
        });
        return;
    }
    
    await m.react('⚡');
    let code = text;
    let isReturn = false;
    
    // مع return
    if (text.trim().startsWith('=> ')) {
        code = text.trim().slice(3);
        isReturn = true;
    } 
    // بدون return
    else if (text.trim().startsWith('> ') || text.trim().startsWith('--> ')) {
        code = text.trim().replace(/^> |^--> /, '');
    }
    
    try {
        const result = await runCode(isReturn ? `return ${code}` : code, { bot, m });
        if (result !== undefined) {
            const output = typeof result === 'string' ? result : util.inspect(result, { depth: 2, maxArrayLength: 10 });
            m.reply(`✅ [${name}]\`\`\`\n${String(output).slice(0, 1500)}\n\`\`\``);
        } else {
            m.reply(`✅ تم التنفيذ [${name}]`);
        }
    } catch (err) {
        m.reply(`❌ \`\`\`${err.message.slice(0, 1000)}\`\`\``);
    }
}

handler.command = /^تنفيذ$/i;
export default handler;