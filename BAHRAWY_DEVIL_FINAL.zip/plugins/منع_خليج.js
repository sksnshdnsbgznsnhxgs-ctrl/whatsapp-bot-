// plugins/anti-gcc.js
// ⧼ 𝑷𝑹𝑶𝑻𝑶𝑻𝒀𝑷𝑬 ⧽v2 - نظام منع الخليج 🇪🇬

import { theme } from '../core/theme.js';

let handler = async (m, { conn, text, isAdmin, isOwner }) => {

  // التحقق من المجموعة
  if (!m.isGroup) {
    return conn.reply(m.chat, `> ${theme.divider}
> 
> 🜲⃝☠️ *خـطـأ*
> 👁️⃝🩸 *هذا الأمر يعمل فقط في المجموعات*
> 
> ${theme.endDivider}`, m);
  }

  // ✅ استخدام isAdmin و isOwner مباشرة (زي أمر جروب)
  if (!isAdmin && !isOwner) {
    return conn.reply(m.chat, `> ${theme.divider}
> 
> 🜲⃝☠️ *خـطـأ*
> 👁️⃝🩸 *هذا الأمر مخصص للمشرفين فقط*
> 
> ${theme.endDivider}`, m);
  }

  // التأكد من كتابة التفعيل أو التعطيل
  if (!text) {
    const currentStatus = global.db.data.settings?.[conn.user.jid]?.blockNonEgypt ? '🟢 مُفعل' : '🔴 مُعطل';
    return conn.reply(m.chat, `> ${theme.divider}
> 
> 🜲⃝☠️ *طـريـقـة الاسـتـخـدام*
> 𖤐⃝🩸 *منع_الخليج [تفعيل/تعطيل]*
> 
> ${theme.smallDivider}
> 
> 👁️⃝🩸 *الـحـالـة الـحـالـيـة:* ${currentStatus}
> 
> ${theme.endDivider}`, m);
  }

  // إنشاء الإعدادات لو غير موجودة
  if (!global.db.data.settings) global.db.data.settings = {};
  if (!global.db.data.settings[conn.user.jid]) {
    global.db.data.settings[conn.user.jid] = { blockNonEgypt: false };
  }

  let setting = global.db.data.settings[conn.user.jid];

  if (text === 'تفعيل') {
    setting.blockNonEgypt = true;
    return conn.reply(m.chat, `> ${theme.divider}
> 
> 🜲⃝☠️ *تـم الـتـفـعـيـل*
> 𖤐⃝🩸 *🇪🇬 نظام منع غير المصريين*
> 
> ${theme.smallDivider}
> 
> 👁️⃝🩸 *الـحـالـة:* 🟢 مُفعلة
> 👁️⃝🩸 *الـمـطـور:* ༺youssf༻
> 
> ${theme.endDivider}`, m);
  } 
  else if (text === 'تعطيل') {
    setting.blockNonEgypt = false;
    return conn.reply(m.chat, `> ${theme.divider}
> 
> 🜲⃝☠️ *تـم الـتـعـطـيـل*
> 𖤐⃝🩸 *تم إيقاف نظام منع غير المصريين*
> 
> ${theme.smallDivider}
> 
> 👁️⃝🩸 *الـحـالـة:* 🔴 مُعطلة
> 
> ${theme.endDivider}`, m);
  } 
  else {
    return conn.reply(m.chat, `> ${theme.divider}
> 
> 🜲⃝☠️ *خـطـأ*
> 👁️⃝🩸 *استخدم: تفعيل أو تعطيل*
> 
> ${theme.endDivider}`, m);
  }
};

// ===============================
// 🔥 نظام الطرد التلقائي عند دخول أعضاء جدد
// ===============================

handler.before = async function (m, { conn, isBotAdmin }) {
  
  // التحقق من وجود أعضاء جدد
  if (!m.isGroup) return;
  if (!m.message?.groupParticipantAdd) return;
  
  // جلب الإعدادات
  let setting = global.db.data.settings?.[conn.user.jid];
  if (!setting?.blockNonEgypt) return;
  
  // التأكد أن البوت أدمن
  if (!isBotAdmin) return;
  
  // جلب بيانات المجموعة
  const groupMetadata = await conn.groupMetadata(m.chat);
  const groupOwner = +855 31 218 0919'-')[0] + '@s.whatsapp.net';
  const botNumber = +260 751187078
  
  // الأعضاء الجدد
  const newMembers = m.message.groupParticipantAdd;
  
  let removed = [];
  let removedNames = [];
  
  for (let user of newMembers) {
    // لا يطرد نفسه
    if (user === botNumber) continue;
    
    // لا يطرد صاحب القروب
    if (user === groupOwner) continue;
    
    const number = user.split('@')[0];
    
    // السماح للأرقام المصرية فقط (كود مصر 20)
    if (number.startsWith('20')) continue;
    
    // طرد العضو غير المصري
    try {
      await conn.groupParticipantsUpdate(m.chat, [user], 'remove');
      removed.push(user);
      // محاولة جلب اسم العضو
      try {
        const contact = await conn.getName(user);
        removedNames.push(contact || number);
      } catch {
        removedNames.push(number);
      }
    } catch (err) {
      console.error('فشل طرد العضو:', err);
    }
  }
  
  // إرسال تقرير إذا تم طرد أعضاء
  if (removed.length > 0) {
    let membersList = removedNames.join(', ');
    await conn.reply(m.chat, `> ${theme.divider}
> 
> 🜲⃝☠️ *⚠️ تـم طـرد أعـضـاء*
> 𖤐⃝🩸 *تم طرد الأعضاء غير المصريين*
> 
> ${theme.smallDivider}
> 
> 👁️⃝🩸 *الأعضاء المطرودين:* ${membersList}
> 👁️⃝🩸 *العدد:* ${removed.length}
> 
> ${theme.smallDivider}
> 
> 𖤐⃝🩸 *🇪🇬 المجموعة للمصريين فقط 🇪🇬*
> 
> ${theme.endDivider}`, m);
  }
};

handler.help = ['منع_الخليج <تفعيل/تعطيل>'];
handler.tags = ['group'];
handler.command = /^منع_الخليج$/i;
handler.group = true;
handler.botAdmin = true;
handler.admin = true;

export default handler;