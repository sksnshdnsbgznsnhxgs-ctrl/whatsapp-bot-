// commands/حلل.js
// ⧼ 𝑷𝑹𝑶𝑻𝑶𝑻𝒀𝑷𝑬 ⧽ v2 - تحليل الروابط والكشف عن الروابط المشبوهة 🛡️

import axios from 'axios';
import { theme } from "../core/theme.js";

let handler = async (m, { conn, text, usedPrefix, command }) => {

    if (!text) {
        await m.react('✍️');
        return conn.reply(m.chat, theme.build([
            { type: 'title', text: 'تحليل الروابط 🛡️' },
            { type: 'spacer' },
            { type: 'info', label: '📌', value: `ضع الرابط بعد الأمر` },
            { type: 'spacer' },
            { type: 'info', label: '📝 مثال', value: `${usedPrefix + command} https://google.com` }
        ]), m);
    }

    if (!/^https?:\/\//i.test(text)) {
        return conn.reply(m.chat, theme.build([
            { type: 'title', text: 'خطأ ❌' },
            { type: 'spacer' },
            { type: 'info', label: '⚠️', value: 'يجب أن يبدأ الرابط بـ http:// أو https://' }
        ]), m);
    }

    await m.react('⏳');
    await m.reply(theme.build([
        { type: 'title', text: 'جاري التحليل' },
        { type: 'spacer' },
        { type: 'info', label: '🛡️', value: 'جاري تحليل الرابط وفحص البروتوكولات...' }
    ]));

    try {
        // ━━━ قائمة الكلمات المشبوهة ━━━
        const suspiciousWords = [
            "login", "verify", "account", "bank", "secure", "update",
            "free", "gift", "bonus", "earn", "crypto", "bitcoin", "pubg",
            "whatsapp", "instagram", "facebook", "password", "username",
            "confirm", "alert", "security", "verify", "unlock", "claim"
        ];

        // ━━━ قائمة مختصري الروابط ━━━
        const shorteners = [
            "bit.ly", "tinyurl", "cutt.ly", "t.co", "goo.gl", "shorturl",
            "is.gd", "ow.ly", "buff.ly", "adf.ly", "shorte.st", "bc.vc",
            "u.to", "cli.gs", "urls.im", "short.com", "short.io"
        ];

        let isSuspicious = false;
        let reasons = [];

        // 1. فحص الكلمات المفتاحية
        for (let word of suspiciousWords) {
            if (text.toLowerCase().includes(word)) {
                isSuspicious = true;
                reasons.push(`يحتوي على كلمة مشبوهة: "${word}"`);
                break;
            }
        }

        // 2. فحص الروابط المختصرة
        if (!isSuspicious) {
            for (let short of shorteners) {
                if (text.includes(short)) {
                    isSuspicious = true;
                    reasons.push(`رابط مختصر (قد يخفي رابطاً ضاراً): ${short}`);
                    break;
                }
            }
        }

        // 3. فحص عناوين IP المباشرة
        if (!isSuspicious && /https?:\/\/\d+\.\d+\.\d+\.\d+/.test(text)) {
            isSuspicious = true;
            reasons.push("يستخدم عنوان IP مباشراً (سلوك مشبوه)");
        }

        // 4. فحص النطاقات غير المعروفة
        const domainMatch = text.match(/https?:\/\/([^\/]+)/);
        if (domainMatch && !isSuspicious) {
            const domain = domainMatch[1];
            if (domain.split('.').length > 3) {
                isSuspicious = true;
                reasons.push(`نطاق فرعي متعدد (قد يكون تصيداً): ${domain}`);
            }
        }

        // 5. فحص استجابة الخادم
        let statusCheck = "غير متاح";
        let serverInfo = "";
        try {
            const res = await axios.get(text, {
                timeout: 8000,
                maxRedirects: 5,
                validateStatus: () => true
            });
            statusCheck = `${res.status} ${res.statusText || 'OK'}`;
            
            if (res.status >= 400) {
                isSuspicious = true;
                reasons.push(`الموقع لا يستجيب بشكل طبيعي (HTTP ${res.status})`);
            }
        } catch (e) {
            statusCheck = "غير مستجيب أو محظور";
            if (!isSuspicious) {
                isSuspicious = true;
                reasons.push("الموقع لا يستجيب أو قد يكون محظوراً");
            }
        }

        await m.react(isSuspicious ? '⚠️' : '✅');

        const resultTitle = isSuspicious ? '⚠️ تنبيه: الرابط مشبوه!' : '✅ النتيجة: الرابط آمن غالباً';
        const resultColor = isSuspicious ? 'warning' : 'success';

        conn.reply(m.chat, theme.build([
            { type: 'title', text: resultTitle },
            { type: 'spacer' },
            { type: 'info', label: '🌐 الرابط', value: text.slice(0, 60) + (text.length > 60 ? '...' : '') },
            { type: 'info', label: '🔎 حالة الموقع', value: statusCheck },
            { type: 'divider' },
            { type: 'info', label: '🛡️ التقييم', value: isSuspicious ? reasons.join(', ') : "لم يتم اكتشاف تهديدات مباشرة" },
            { type: 'spacer' },
            { type: 'info', label: '⚡', value: global.botName || '𓆩☠️𓆪 𝗕𝗔𝗛𝗥𝗔𝗪𝗬 𝗗𝗘𝗩𝗜𝗟 𓆩☠️𓆪 😈' }
        ]), m);

    } catch (err) {
        await m.react('❌');
        console.error("Link checker error:", err);
        
        conn.reply(m.chat, theme.build([
            { type: 'title', text: 'فشل التحليل ❌' },
            { type: 'spacer' },
            { type: 'info', label: '⚠️', value: 'حدث خطأ أثناء محاولة الاتصال بالرابط' },
            { type: 'spacer' },
            { type: 'info', label: '💡', value: 'تأكد من صحة الرابط وجرب مرة أخرى' }
        ]), m);
    }
};

handler.help = ['حلل [رابط]'];
handler.tags = ['tools'];
handler.command = /^(حلل|فحص_رابط|تحليل|checklink)$/i;

export default handler;