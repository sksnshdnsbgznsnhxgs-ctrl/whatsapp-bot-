// plugins/q8-unions.js
// ⧼ 𝑷𝑹𝑶𝑻𝑶𝑻𝒀𝑷𝑬 ⧽v2 - قسم النقابات 👥

import { prepareWAMessageMedia, generateWAMessageFromContent, proto } from '@whiskeysockets/baileys';
import fetch from 'node-fetch';
import { theme } from '../core/theme.js';

let handler = async (m, { conn, usedPrefix: _p }) => {
  try {
    // تفاعل البوت
    await conn.sendMessage(m.chat, { react: { text: '👥', key: m.key } });

    // جلب اسم المستخدم
    const user = await conn.getName(m.sender);
    
    // 🔥 الصورة المحددة لقسم النقابات
    const imageUrl = 'https://file.garden/aauvg01sjleV_ic1/file_00000000b218720a9e84a5ecfd6171da.png';
    
    // تحميل الصورة
    const imageRes = await fetch(imageUrl);
    const imageBuffer = Buffer.from(await imageRes.arrayBuffer());
    const media = await prepareWAMessageMedia({ image: imageBuffer }, { upload: conn.waUploadToServer });

    // بناء قائمة أوامر النقابات
    let menuText = `*╭━━ 𝐔𝐍𝐈𝐎𝐍𝐒 ━━⃝💙*\n`
    menuText += `*│* *『 ❐╎ تلقيب ⃝💙 』*\n`
    menuText += `*│* *『 ❐╎ حجز_لقب ⃝💙 』*\n`
    menuText += `*│* *『 ❐╎ الالقاب_المحجوزه ⃝💙 』*\n`
    menuText += `*│* *『 ❐╎ الغاء_حجز ⃝💙 』*\n`
    menuText += `*│* *『 ❐╎ متوفر ⃝💙 』*\n`
    menuText += `*│* *『 ❐╎ لقبي ⃝💙 』*\n`
    menuText += `*│* *『 ❐╎ حذف_لقب ⃝💙 』*\n`
    menuText += `*│* *『 ❐╎ حذف_الألقاب ⃝💙 』*\n`
    menuText += `*│* *『 ❐╎ لقبه ⃝💙 』*\n`
    menuText += `*│* *『 ❐╎ رسايلي ⃝💙 』*\n`
    menuText += `*│* *『 ❐╎ اجمالي ⃝💙 』*\n`
    menuText += `*╰━━━━━━━━━━━━━⃝💙*\n\n`

    // إضافة تذييل أو ترحيب اختياري
    menuText += `> 𖤐⃝👥 *مرحباً ${user}، هذا قسم إدارة النقابات والألقاب*`;

    // بناء الرسالة التفاعلية
    const nativeFlowPayload = {
      body: { text: menuText },
      footer: { text: '⧼ 𝑷𝑹𝑶𝑻𝑶𝑻𝒀𝑷𝑬 ⧽ v2 👥' },
      header: {
        hasMediaAttachment: true,
        subtitle: '👥 قـسـم الـنـقـابـات',
        imageMessage: media.imageMessage
      },
      nativeFlowMessage: {
        buttons: [
          {
            name: 'quick_reply',
            buttonParamsJson: JSON.stringify({
              display_text: '🔙 الـعـودة للـقـائـمـة',
              id: '.الاوامر'
            })
          },
          {
            name: 'quick_reply',
            buttonParamsJson: JSON.stringify({
              display_text: '👑 الـمـطـور',
              id: '.المطور'
            })
          }
        ],
        messageParamsJson: JSON.stringify({
          bottom_sheet: {
            in_thread_buttons_limit: 1,
            list_title: "👥 قـسـم الـنـقـابـات",
            button_title: "خـيـارات"
          }
        })
      }
    };

    const interactiveMessage = proto.Message.InteractiveMessage.fromObject(nativeFlowPayload);
    const fkontak = await makeFkontak();
    
    // إنشاء وإرسال الرسالة
    const msg = generateWAMessageFromContent(m.chat, { 
      viewOnceMessage: {
        message: {
          interactiveMessage: interactiveMessage
        }
      }
    }, { 
      userJid: conn.user.jid, 
      quoted: fkontak 
    });
    
    await conn.relayMessage(m.chat, msg.message, { messageId: msg.key.id });

  } catch (e) {
    console.error('خطأ في قسم النقابات:', e);
    await conn.sendMessage(m.chat, { 
      text: theme.build([
        { type: 'error', text: '❌ حدث خطأ في تحميل قسم النقابات' },
        { type: 'info', label: 'السبب', value: e.message || 'خطأ غير معروف' }
      ])
    }, { quoted: m });
  }
}

// دالة لعمل كونتاك وهمي للاقتباس
async function makeFkontak() {
  try {
    const res = await fetch('https://file.garden/aauvg01sjleV_ic1/a2075690da240b4d4af5e9affed48bbe.jpg');
    const thumb2 = Buffer.from(await res.arrayBuffer());
    return {
      key: { participants: '0@s.whatsapp.net', remoteJid: 'status@broadcast', fromMe: false, id: 'Halo' },
      message: { locationMessage: { name: '⧼ 𝑷𝑹𝑶𝑻𝑶𝑻𝒀𝑷𝑬 ⧽ v2', jpegThumbnail: thumb2 } },
      participant: '0@s.whatsapp.net'
    };
  } catch {
    return undefined;
  }
}

handler.help = ['ق8'];
handler.tags = ['main'];
handler.command = ['ق8', 'unions', 'نقابات'];

export default handler;