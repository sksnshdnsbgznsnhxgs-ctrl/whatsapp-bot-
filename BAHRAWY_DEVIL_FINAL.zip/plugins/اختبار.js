// plugins/test-mention.js
// ⧼ 𝑷𝑹𝑶𝑻𝑶𝑻𝒀𝑷𝑬 ⧽v2 - اختبار المنشن 🧪

import { theme } from '../core/theme.js';

let handler = async (m, { conn, text, usedPrefix, command }) => {

    // طريقة 1: استخدام m.mentionedJid
    let mentions1 = m.mentionedJid || [];
    
    // طريقة 2: استخدام parseMention من الرسالة (إذا كانت موجودة)
    let mentions2 = [];
    if (typeof m.parseMention === 'function') {
        mentions2 = m.parseMention();
    }
    
    // طريقة 3: استخدام conn.parseMention
    let mentions3 = [];
    if (m.text && typeof conn.parseMention === 'function') {
        mentions3 = conn.parseMention(m.text);
    }
    
    // طريقة 4: البحث اليدوي في النص
    let mentions4 = [];
    if (m.text) {
        const matches = m.text.match(/@([0-9]{5,16}|[a-zA-Z0-9_-]+)/g);
        if (matches) {
            mentions4 = matches.map(v => v.slice(1) + '@s.whatsapp.net');
        }
    }
    
    // طريقة 5: البحث عن أرقام مباشرة
    let mentions5 = [];
    if (m.text) {
        const numMatches = m.text.match(/\b([0-9]{10,15})\b/g);
        if (numMatches) {
            mentions5 = numMatches.map(v => v + '@s.whatsapp.net');
        }
    }
    
    // جمع كل المنشنات من جميع الطرق
    const allMentions = [...new Set([...mentions1, ...mentions2, ...mentions3, ...mentions4, ...mentions5])];
    
    // أسماء المستخدمين المذكورين
    let mentionNames = [];
    for (const jid of allMentions) {
        try {
            const name = await conn.getName(jid);
            mentionNames.push(`${name} (${jid.split('@')[0]})`);
        } catch {
            mentionNames.push(jid.split('@')[0]);
        }
    }
    
    const resultText = theme.build([
        { type: 'title', text: '🧪 اختبار المنشن' },
        { type: 'spacer' },
        { type: 'info', label: '📝 النص الأصلي', value: m.text || '(لا يوجد نص)' },
        { type: 'divider' },
        { type: 'info', label: '🎯 m.mentionedJid', value: mentions1.length > 0 ? mentions1.join(', ') : '❌ لا يوجد' },
        { type: 'info', label: '🔧 m.parseMention()', value: mentions2.length > 0 ? mentions2.join(', ') : '❌ لا يوجد' },
        { type: 'info', label: '⚙️ conn.parseMention()', value: mentions3.length > 0 ? mentions3.join(', ') : '❌ لا يوجد' },
        { type: 'info', label: '🔍 البحث اليدوي (@)', value: mentions4.length > 0 ? mentions4.join(', ') : '❌ لا يوجد' },
        { type: 'info', label: '🔢 الأرقام المباشرة', value: mentions5.length > 0 ? mentions5.join(', ') : '❌ لا يوجد' },
        { type: 'divider' },
        { type: 'info', label: '✅ المنشن المستخرج', value: allMentions.length > 0 ? allMentions.join(', ') : '❌ لا يوجد منشن' },
        { type: 'info', label: '👤 أسماء المذكورين', value: mentionNames.length > 0 ? mentionNames.join(', ') : 'لا يوجد' }
    ]);
    
    await conn.sendMessage(m.chat, { react: { text: '🧪', key: m.key } });
    await m.reply(resultText);
};

handler.help = ['اختبار'];
handler.tags = ['tools'];
handler.command = /^(اختبار|testmentions|testmention)$/i;

export default handler;