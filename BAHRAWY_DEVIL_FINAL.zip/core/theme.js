// core/theme.js
// ⧼ 𓆩☠️𓆪 𝗕𝗔𝗛𝗥𝗔𝗪𝗬 𝗗𝗘𝗩𝗜𝗟 𓆩☠️𓆪 😈 ⧽ v2 - زخرفة ليلية 🌙

export const theme = {
  // الرموز الأساسية (ليلة)
  skull: '🌙',
  blood: '⭐',
  virus: '🌠',
  eye: '✨',
  sword: '💫',
  target: '☾',
  darkStar: '『🌙』',
  lightStar: '『✨』',
  
  // فواصل ليلية
  divider: '❖ ━━━━━━━━━━━━━━━ ❖',
  smallDivider: '❖ ━━━━━ ❖',
  endDivider: '❖ ━━━━━━━━━━━━━━━ ❖',
  
  // تنسيق النص
  title: (text) => `> ☾ *${text}*`,
  subtitle: (text) => `> ⭐ *${text}*`,
  info: (text) => `> ✨ *${text}*`,
  warning: (text) => `> 🌙 *${text}* 🌙`,
  success: (text) => `> ✓ *${text}*`,
  error: (text) => `> ✗ *${text}*`,
  
  // build full message
  build: (sections) => {
    let msg = `> ${theme.divider}\n>\n`
    for (const section of sections) {
      if (section.type === 'title') {
        msg += `> ☾ *${section.text}*\n`
      } else if (section.type === 'subtitle') {
        msg += `> ⭐ *${section.text}*\n`
      } else if (section.type === 'info') {
        msg += `> ✨ ${section.label}: ${section.value}\n`
      } else if (section.type === 'line') {
        msg += `> ${section.text}\n`
      } else if (section.type === 'divider') {
        msg += `> ${theme.smallDivider}\n`
      } else if (section.type === 'spacer') {
        msg += `> \n`
      }
    }
    msg += `>\n> ${theme.endDivider}`
    return msg
  }
}

export const formatWithTheme = (data) => {
  return theme.build(data)
}