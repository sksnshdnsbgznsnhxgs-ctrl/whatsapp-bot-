// plugins/talkeeb.js
// ⧼ 𝑷𝑹𝑶𝑻𝑶𝑻𝒀𝑷𝑬 ⧽ v2 - تسجيل لقب لعضو في المجموعة 👥

let handler = async (m, { conn, text, usedPrefix, command }) => {
    try {
        let mentionedJid;
        let name;
        const groupId = m.chat;

        // تحديد العضو واللقب
        if (m.quoted && m.quoted.sender) {
            mentionedJid = m.quoted.sender;
            name = text ? text.trim() : null;
        } else if (text && text.match(/(?:@([^\s]+))\s*(.*)/i)) {
            const match = text.match(/(?:@([^\s]+))\s*(.*)/i);
            if (match) {
                mentionedJid = match[1] + '@s.whatsapp.net';
                name = match[2].trim();
            }
        }

        // التحقق من صحة الإدخال
        if (!mentionedJid) {
            return m.reply(`✍️ *الاستخدام الصحيح:*\n${usedPrefix + command} @العضو اللقب\nأو رد على رسالة العضو واكتب ${usedPrefix + command} اللقب`);
        }
        
        if (!name) {
            return m.reply(`✍️ يرجى إدخال اللقب`);
        }

        // التحقق من وجود قاعدة البيانات
        if (!global.db.data) global.db.data = {};
        if (!global.db.data.users) global.db.data.users = {};

        // جلب بيانات المستخدم
        let user = global.db.data.users[mentionedJid] || {};
        if (!user.groups) user.groups = {};

        // التحقق من التسجيل السابق
        if (user.groups[groupId] && user.groups[groupId].name) {
            return m.reply(`❌ هذا العضو مسجل مسبقاً بلقب: ${user.groups[groupId].name}`);
        }

        // التحقق من تكرار اللقب في نفس المجموعة
        let found = false;
        for (let key in global.db.data.users) {
            const u = global.db.data.users[key];
            if (u.groups && u.groups[groupId] && u.groups[groupId].name &&
                u.groups[groupId].name.toLowerCase() === name.toLowerCase()) {
                found = true;
                break;
            }
        }
        
        if (found) {
            return m.reply(`⚠️ هذا اللقب مستخدم من قبل عضو آخر`);
        }

        // التسجيل
        user.groups[groupId] = { 
            name: name, 
            regTime: Date.now(), 
            registered: true 
        };
        global.db.data.users[mentionedJid] = user;

        // حفظ في قاعدة البيانات إن وجدت
        if (global.db.writeData) {
            try {
                await global.db.writeData('users', mentionedJid, user);
            } catch(e) {}
        }

        // الحصول على اسم العضو (طريقة آمنة)
        let memberName = mentionedJid.split('@')[0];
        try {
            const nameFromConn = await conn.getName(mentionedJid);
            if (nameFromConn) memberName = nameFromConn;
        } catch(e) {
            // استخدام الرقم إذا فشل جلب الاسم
        }
        
        // رسالة النجاح
        let successMsg = `╭━━ 👥 *تسجيل لقب* ━━⃝💙
│
│ ✅ *تم التسجيل بنجاح*
│
│ 👤 *العضو:* ${memberName}
│ 🏷️ *اللقب:* ${name}
│ 📅 *التاريخ:* ${new Date().toLocaleDateString('ar-EG')}
│ ⏰ *الوقت:* ${new Date().toLocaleTimeString('ar-EG')}
│
╰━━━━━━━━━━━━━⃝💙`;

        await conn.sendMessage(m.chat, { text: successMsg }, { quoted: m });

    } catch (err) {
        console.error('تلقيب error:', err);
        await m.reply(`❌ حدث خطأ: ${err.message || err}`);
    }
};

// إعدادات الأمر
handler.help = ['تلقيب @user لقب'];
handler.tags = ['unions'];
handler.command = /^(تلقيب|register|تسجيل)$/i;
handler.admin = true;
handler.group = true;
handler.botAdmin = true;

export default handler;